package com.dev.assesment;


public interface EmployeeInterface {
	public boolean addData(String s,Employee emp);
    public void getData();
	public boolean removeData(String s,Employee emp);
	public boolean searchData(String s,Employee empid);

	
		

	}





