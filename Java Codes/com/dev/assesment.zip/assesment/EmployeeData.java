package com.dev.assesment;

import com.dev.encapsulation.Dog;

public class EmployeeData {

	public static void main(String[] args) {
		Employee e1 = new Employee();
		Employee e2 = new Employee();
		
		
		e1.setEmpid(100);
		e1.setEname("Dhoni");
		e1.setEmail("dhoni@gmail.com");
	    e1.setSalary(435);
		e1.setPassword("362547dhg");
		
		e2.setEmpid(101);
		e2.setEname("Virat");
		e2.setEmail("Virat@gmail.com");
	    e2.setSalary(436);
		e2.setPassword("3625ytu");
		
	gundamrajeshwari8008@gmail.com
		 
		Employee [] emps = {e1,e2};
		
		for(int i=0; i<=emps.length;i++) {
			System.out.println("Empid: "+emps[i].getEmpid());
			System.out.println("Ename: "+emps[i].getEname());
			System.out.println("Email: "+emps[i].getEmail());
			System.out.println("Salary: "+emps[i].getSalary());
			
			

	}

	}
}
