package com.dev.assesment;

import java.util.HashMap;


import com.dev.practice.Dog;

public class EmployeeImplementation implements EmployeeInterface {

	public static void main(String[] args) {
		HashMap<String,Employee> hm = new HashMap<>();
		
	
		@Override
		public boolean addData(Employee emp) {
			System.out.println("Adding data :");
			if(emp!=null) {
				hm.add(emp);
				return true;
			}
			    return false;
			   
		   }


	@Override
	public void getData() {
		System.out.println("getting data :"+hm);
		

	}
	@Override
	public boolean removeData(Employee emp) {
		System.out.println("remove data :");
		boolean b = hm.remove(emp);
		   if(b) {
			   return true;
		   }  

		return false;
	}
	




		

	}

}
